#include <stdio.h>

int		ft_fibonacci(int index);

int		main(void)
{	
	printf("Fibonacci of 0     : 0 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(0));

	printf("Fibonacci of 1     : 1 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(1));
	
	printf("Fibonacci of -17   : -1 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(-17));

	printf("Fibonacci of 5     : 5 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(5));

	printf("Fibonacci of 10    : 55 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(10));

	printf("Fibonacci of 15    : 610 \n");
	printf("Result of function : %d\n\n", ft_fibonacci(15));

	return (0);
}
