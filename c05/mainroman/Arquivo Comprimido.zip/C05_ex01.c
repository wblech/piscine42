#include <stdio.h>

int		ft_recursive_factorial(int nb);

int		main(void)
{	
	printf("Factorial of -1 is : 0 \n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(-1));

	printf("Factorial of 0 is  : 1 \n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(0));

	printf("Factorial of 1 is  : 1\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(1));

	printf("Factorial of 2 is  : 2\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(2));

	printf("Factorial of 3 is  : 6\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(3));

	printf("Factorial of 4 is  : 24\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(4));

	printf("Factorial of 5 is  : 120\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(5));

	printf("Factorial of 6 is  : 720\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(6));

	printf("Factorial of 7 is  : 5040\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(7));

	printf("Factorial of 8 is  : 40320\n");
	printf("Result of function : %d\n\n", ft_recursive_factorial(8));

	return (0);
}
