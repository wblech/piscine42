#include <stdio.h>

int		ft_ten_queens_puzzle(void);

int		main(void)
{	
	printf("Function return        : %d\n", ft_ten_queens_puzzle());
	printf("Function should return : 724\n");
	return (0);
}
