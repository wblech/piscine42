#include <stdio.h>

int		ft_iterative_power(int nb, int power);

int		main(void)
{	
	printf("1 power  -1 is     : 0 \n");
	printf("Result of function : %d\n\n", ft_iterative_power(1, -1));

	printf("0 power 0 is       : 1 \n");
	printf("Result of function : %d\n\n", ft_iterative_power(0, 0));

	printf("-9 power of 3 is   : -729\n");
	printf("Result of function : %d\n\n", ft_iterative_power(-9, 3));

	printf("-9 power of 1 is   : -9\n");
	printf("Result of function : %d\n\n", ft_iterative_power(-9, 1));

	printf("-9 power of 0 is   : 1\n");
	printf("Result of function : %d\n\n", ft_iterative_power(-9, 0));

	printf("0 power of 1 is    : 0\n");
	printf("Result of function : %d\n\n", ft_iterative_power(0, 1));

	printf("1 power of 0 is    : 1\n");
	printf("Result of function : %d\n\n", ft_iterative_power(1, 0));

	printf("4 power of 4 is    : 256\n");
	printf("Result of function : %d\n\n", ft_iterative_power(4, 4));

	printf("7 power of 8 is    : 5764801\n");
	printf("Result of function : %d\n\n", ft_iterative_power(7, 8));
	
	printf("2 power  0 is      : 1 \n");
	printf("Result of function : %d\n\n", ft_iterative_power(2, -0));

	return (0);
}
