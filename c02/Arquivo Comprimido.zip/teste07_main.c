#include <stdio.h>

char	*ft_strupcase(char *str);

int	main(void)
{
	char str[] = "teste";
	char str1[] = "PASSAR";
	char str2[] = "tes456";
	char str3[] = "AqUiOh";
	char *teste1;
	char *teste2;
	//char *teste3;
	//char *teste4;

	printf("Original: %s\n", str);
	teste1 = ft_strupcase(str);
   	printf("Maiuscula: %s\n", teste1);	
	
	printf("Original: %s\n", str1); 
	teste2 = ft_strupcase(str1);
   	printf("Maiuscula: %s\n", teste2);	
	
	printf("Original: %s\n", str2); 
   	printf("Maiuscula: %s\n", ft_strupcase(str2));	
	
	printf("Original: %s\n", str3); 
   	printf("Maiuscula: %s\n", ft_strupcase(str3));

return (0);	
}
