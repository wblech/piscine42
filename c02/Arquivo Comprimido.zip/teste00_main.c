#include <stdio.h>

void	*ft_strcpy(char *dest, char *src);

int		main(void)
{
	char dest[50];
	char src[] = "Frase de Teste";
	
	ft_strcpy(dest, src);
	printf("SRC: %s", src);
	printf("DST: %s", dest);
}
