void	ft_putstr_with_non_printable(char *str);

int		main(void)
{
	char str[] = "Oi\nvoce esta bem?";
//	char str[] = "Oi\0voce esta bem?";

	ft_putstr_with_non_printable(str);
}
