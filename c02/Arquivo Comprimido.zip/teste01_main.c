#include <stdio.h>

char 	*ft_strncpy(char *dest, char *src, unsigned int n);

int		main(void)
{
	char dest[20];
	char *src;
	unsigned int size;

	size = 10;
	src = "teste";
	ft_strncpy(dest, src, size);
	printf("O size é %i\n", size);
	printf("O src é %s\n", src);
	printf("O dst é %s\n", dest);


}
