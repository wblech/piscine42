#include <string.h>
#include <stdio.h>

unsigned int ft_strlcpy(char *dest, char *src, unsigned int size); 

int	main(void)
{
	char src_original[] = "casa";
	char dst_original[] = "pata";
	size_t size_original;
	size_t retorno_original;

	char src_meu[] = "casa";
	char dst_meu[] = "pata";
	unsigned int size_meu;
	unsigned int retorno_meu;


	size_original = 1;

	size_meu = -1;
	
	/*   */
	
	retorno_original = strlcpy(dst_original, src_original, size_original);
	printf("strlcpy(src): %s\n", src_original);
	printf("strlcpy(dst): %s\n", dst_original);
//	printf("strlcpy(dst-alterado): %s\n", strlcpy(dst_original, src_original, size_original);
	printf("strlcpy(size): %zu\n", size_original);
	printf("strlcpy(src): %zu\n", retorno_original);
	printf("\n");
	retorno_meu = ft_strlcpy(dst_meu, src_meu, size_meu);
	printf("ft_strlcpy(src): %s\n", src_meu);
	printf("ft_strlcpy(dst): %s\n", dst_meu);
//	printf("ft_strlcpy(dst-alterado): %s\n", ft_strlcpy(dst_meu, src_meu, size_meu);
	printf("ft_strlcpy(size): %i\n", size_meu);
	printf("ft_strlcpy(src): %i\n", retorno_meu);
}


