#include <stdio.h>

int	ft_str_is_numeric(char *str);

int	main(void)
{
	char *str = "teste";
	char *str1 = "123";
	char *str2 = "tes456";
	char *str3 = "AqUiFoi";
	int teste1;
	int teste2;
	int teste3;
	int teste4;


	teste1 = ft_str_is_numeric(str);
	teste2 = ft_str_is_numeric(str1);
	teste3 = ft_str_is_numeric(str2);
	teste4 = ft_str_is_numeric(str3);


	printf("%s: ", str);
	printf("%i: ", teste1);
	printf("\n");

	printf("%s: ", str1);
	printf("%i: ", teste2);
	printf("\n");

	printf("%s: ", str2);
	printf("%i: ", teste3);
	printf("\n");

	printf("%s: ", str3);
	printf("%i: ", teste4);
	printf("\n");


}
