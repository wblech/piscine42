#include <stdio.h>

void	ft_putstr(char *str);

int		main(void)
{
	char *str;

	str  = "teste";
	ft_putstr(str);
}
